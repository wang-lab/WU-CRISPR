#!/usr/bin/perl

use strict;
use warnings;
use lib '/var/www/cgi-bin';
use Cwd;

use File::Path;

my @inputs = @ARGV;

my $resultFileTail = shift @inputs;
my $submittedSeq = shift @inputs;



my $version =         'V0.9';
my $file_dir =        './';
my $result_dir =     './temp/result_'.$resultFileTail;
my $libsvm_dir =      './libsvm-2.82';
my $classifier_dir =  "./SVM_model";

my $result_file =       "./temp/gOligo_prediction_result_$resultFileTail.xls";
my $feature_file =    "$classifier_dir/feature_list_v0.9.txt";

my $scaffold_seq = "GTTTTAGAGCTAGAAATAGCAAGTTAAAATAAGGCTAGTCCGTTATCAACTTGAAAAAGTGGCACCGAGTCGGTGCTTT";

my $min_pos = 0;    
my $max_pos = 100000000; 
my $retained_portion = 1; 


$submittedSeq =~ tr/ATCGU/atcgu/; $submittedSeq =~ tr/u/t/;
print "\n******************** Genome-Wide sgOligo Version $version Standard Output **************************\n";

unlink $result_file if -e $result_file;
mkdir $result_dir if !(-e $result_dir);

my ($dH_ref, $dS_ref, $dG_ref, $dHi, $dSi, $dGi) = rna_dna_param();
my %dG = %{$dG_ref};

$scaffold_seq =~ tr/ATCGU/atcgu/;  $scaffold_seq =~ tr/t/u/;

my %p_val = import_p($feature_file);

my @feature;    
my @annotation; 
my %oligo_pos; 
my $gene_count = 0;
my $line_count = 0;
my $total_line_count = 0;

my $submittedSeq_rc = dnaComplement($submittedSeq);

generate_feature($submittedSeq,"sense");
generate_feature($submittedSeq_rc,"antisense");

predict(\@feature, \@annotation);


print "\n************* sgOligo selection process is done. Program completed successfully. *******************\n";

system("rm -rf $result_dir");
#####################################################################################################################################################################
sub generate_feature {

    my ($exon_plus,$orientation) = @_;
    
    my $dummyString = 'n'x50;
    $exon_plus = join("",$dummyString,$exon_plus,$dummyString);

    my $exon = substr($exon_plus, 50, length($exon_plus) - 100);

    my $seqStrand = $exon_plus;
    $seqStrand = dnaComplement($exon_plus) if $orientation eq 'antisense'; #return to the original sequence

    my @gg_pos_list;
    for (my $i =0; $i<length($exon);$i++){
        my $dinuc = substr($exon,$i,2);
        push @gg_pos_list, $i if $dinuc eq 'gg';
   }
    foreach my $gg_pos (@gg_pos_list) {
 
            my $oligo = substr($exon_plus, $gg_pos + 50 - 21, 24);
            next if $oligo =~ /n/g;
            
            my $matched_bases = $oligo;
            $matched_bases = dnaComplement($oligo) if $orientation eq 'antisense';
            
            my $cds_pos = index($seqStrand,$matched_bases)+1;

            my $output = generate_feature_line($oligo); # return '' if failed the pre-filters

            if ($output) {
                 $feature[$line_count] = $output;

                 my $exon_pos = $gg_pos;
                 $exon_pos = length($exon) - $gg_pos if $orientation eq "antisense";
                 $exon_pos += 1; # 1-based index position

                 $annotation[$line_count] = "$orientation\t$exon_pos\t$cds_pos\t".length($exon_plus)."\t$oligo";

                 $line_count++;
            }
            $total_line_count++;
    }
}
sub generate_feature_line {

    my $extSeq = shift;
    $extSeq =~ tr/t/u/;

    my $seq = substr($extSeq, 0, 20);

    my $output = '';
    my $feature_count = 0;

    # ************* Position-specific base composition *******************************************************************

    my $offset = -1; # use the extended sequence to include the PAM sequence; different from the training sequences which have four extra bases at the 5' end
    my $exclude_pos = 0;

    for (my $indx = 0; $indx < length($extSeq); $indx++) {

          next if $indx == $offset + 1 or $indx == $offset + 2 or $indx == $offset + 4 or $indx == $offset + 5
                   or $indx == $offset + 6 or $indx == $offset + 7 or $indx == $offset + 8 or $indx == $offset + 13 or $indx == $offset + 22 or $indx == $offset + 23;

          my $base = substr($extSeq, $indx, 1);
          my $a_base = 0;
          my $c_base = 0;
          my $g_base = 0;
          my $ut_base = 0;

          if ($base eq 'a') {
             $a_base = 1;
          }
          elsif ($base eq 'c') {
                $c_base = 1;
          }
          elsif ($base eq 'g') {
                $g_base = 1;
          }
          elsif ($base eq 'u') {
                $ut_base = 1;
          }

          $output .= (++$feature_count) . ":$a_base " . (++$feature_count) . ":$c_base ";
          $output .= (++$feature_count) . ":$g_base " . (++$feature_count) . ":$ut_base ";

          $exclude_pos = 1 if $indx == 18 and $ut_base == 1;
          $exclude_pos = 1 if $indx == 19 and $ut_base == 1;
          $exclude_pos = 1 if $indx == 19 and $c_base == 1;
    }
    return ''  if $exclude_pos == 1;

    # ****************************************************************************************************************

    # ******************UUU (within last six bases); PolyX in the gRNA***********************************************

    my $polyA_reject_length = 5;
    my $polyC_reject_length = 5;
    my $polyG_reject_length = 4;
    my $polyU_reject_length = 4; 

    return '' if substr($seq, -6, 6) =~ /uuu/;
    return '' if $seq =~ /a{$polyA_reject_length}/ || $seq =~ /c{$polyC_reject_length}/ || $seq =~ /g{$polyG_reject_length}/ || $seq =~ /u{$polyU_reject_length}/;

    # ****************************************************************************************************************

    # ************** GC Content ********************************************************************************
    my $gc_content = gcPercent($seq);
    
    return '' if $gc_content > 0.8;

    $output .= (++$feature_count) . ":$gc_content ";

    # **********************************************************************************************************

    # ************** Duplex binding stability ******************************************************************
    my $binding_flag = 0;
    for (my $start = 0; $start < length($seq) - 4; $start++) {

          next unless $start == 0 or $start == 7;

          my $dG_binding = dG_binding(substr($seq, $start, length($seq)-$start));

          $output .= (++$feature_count) . ":$dG_binding ";

          $binding_flag = 1 if ($start == 0 and $dG_binding >= -18) or ($start == 7 and $dG_binding < -22) or ($start == 7 and $dG_binding > -9);
    }

    return '' if $binding_flag == 1;

    # ************************************************************************************************************

    # ************** Base accessibility (alignment) ******************************************************************
    my $dG_folding = foldingdG($seq);
        
    return '' if $dG_folding < -8;

    $output .= (++$feature_count) . ":$dG_folding ";

    my $gRNA = $seq . $scaffold_seq;
    my ($dG_folding1, $alignment) = RNA_fold($gRNA);
    
    my $ext_stem = "(((((((((.((((....))))...)))))))";
    my $aligned_stem = substr($alignment, 18, length($ext_stem));

    return '' if $aligned_stem eq $ext_stem;

    $alignment =~ tr/\.\(\)/011/;
    my @aligned = split "", $alignment;
    for (my $i = 0; $i <= $#aligned; $i++) {

          next unless $i == 14 or $i == 17 or $i == 18 or $i == 19 or $i == 20 or $i == 50 or $i == 51 or $i == 52;

          $output .= (++$feature_count) . ":" . $aligned[$i] . " ";
    }
    # ************************************************************************************************************

    # **************mono-, di- and tri-nucleotide compoisition *********************************************************
    my %base_num = (0 => 'a', 1 => 'u', 2 => 'c', 3 => 'g');
    my %dimer_count;
    my %trimer_count;
    my %tetramer_count;

    my @base_ary = $seq =~ /a/g; $output .= (++$feature_count) . ':' . scalar(@base_ary) . ' ';
    @base_ary = $seq =~ /u/g; $output .= (++$feature_count) . ':' . scalar(@base_ary) . ' ';
    @base_ary = $seq =~ /c/g; $output .= (++$feature_count) . ':' . scalar(@base_ary) . ' ';
    @base_ary = $seq =~ /g/g; $output .= (++$feature_count) . ':' . scalar(@base_ary) . ' ';

    for (my $pos = 0; $pos < length($seq)-1; $pos++) {
         my $dimer = substr($seq, $pos, 2);
         $dimer_count{$dimer}++;
    }
    for (my $i = 0; $i <= 3; $i++) {
         for (my $j = 0; $j <= 3; $j++) {
             my $dimer = $base_num{$i} . $base_num{$j};
             $dimer_count{$dimer} = 0 if !exists $dimer_count{$dimer};
             $output .= (++$feature_count) . ':' . $dimer_count{$dimer} . ' ';
         }
    }

    for (my $pos = 0; $pos < length($seq)-2; $pos++) {
         my $trimer = substr($seq, $pos, 3);
         $trimer_count{$trimer}++;
    }
    for (my $i = 0; $i <= 3; $i++) {
         for (my $j = 0; $j <= 3; $j++) {
              for (my $m = 0; $m <= 3; $m++) {
                        my $trimer = $base_num{$i} . $base_num{$j} . $base_num{$m};
                        $trimer_count{$trimer} = 0 if !exists $trimer_count{$trimer};
                        $output .= (++$feature_count) . ':' . $trimer_count{$trimer} . ' ';
             }
         }
    }

    # **********************************************************************************************************
    # All the features have been generated. Now it is time to generate the output line
    # **********************************************************************************************************

    $output = -1 . " " . $output;

    return $output;
}

sub predict {

    my ($feature_ref, $annotation_ref) = @_;
    my @feature = @{$feature_ref};

    open(PREDICT, ">$result_dir/sgOligo_predict.txt");
    for (my $j = 0; $j <= $#feature; $j++) {
         print PREDICT p_cutoff($feature[$j]) . "\n";
    }
    close(PREDICT);

    libsvm($annotation_ref);
}


sub import_p {
    my $file = shift;
    my %p;
    open(IN, $file) or die "Cannot open file for reading: $!\n";
    while (<IN>) {
         $_ =~ s/\s+$//;
         my @line = split /\t/, $_;
         $p{$line[0]} = 1;  
    }
    close(IN);
    return %p;
}

sub p_cutoff {
    my $feat_line = shift;
    my @feature = split / /, $feat_line;

    my @output;
    # Feature count is 1-based, not 0-based.
    for (my $i = 1; $i <= $#feature; $i++) {
         my ($index, $value) = split /:/, $feature[$i];
         push @output, $value if exists $p_val{$index};
    }
    my $out_string = $feature[0] . ' ';  
    for (my $j = 0; $j <= $#output; $j++) {
         $out_string .= ($j+1) . ':' . $output[$j] . ' ';
    }
    return $out_string;

}


sub libsvm {

    my ($annotation_ref) = @_;

    my $param_c;
    my $param_g;

    my $command1 = "$libsvm_dir/svm-scale -r $classifier_dir/sgOligo_train.range $result_dir/sgOligo_predict.txt > $result_dir/sgOligo_predict.scale";
    system($command1);

    my $command2 = "$libsvm_dir/svm-predict -b 1 $result_dir/sgOligo_predict.scale $classifier_dir/sgOligo_train.scale.model $result_dir/sgOligo.predict.xls";
    system($command2);

    my @prediction;
    my @annotation = @{$annotation_ref};

    my $reverse_order = 0;
    open(SVM, "$result_dir/sgOligo.predict.xls") or die "cannot open file1 for reading: $!\n";
    while(<SVM>){
           $_ =~ s/\s+$//;
           my @line = split / /, $_;

           if ($line[0] eq 'labels') {   
                if ($line[2] == -1) {
                     $reverse_order = 1;
                }
           }
           my $new_line = $_;
           $new_line = join (" ", ($line[0], $line[2], $line[1])) if $reverse_order == 1;
           push @prediction, $new_line;

    }
    close(SVM);

    open(OUT, ">$result_file");
    print OUT "$submittedSeq\n";

    my @svm_header = split / /, $prediction[0];
    print OUT join("\t", @svm_header), "\tOrientation\tPosition in Exon\tPosition in CDS\tCDS Length\tOligo Sequence\n";

    for (my $i = 1; $i <= $#prediction; $i++) {
         my @pred = split / /, $prediction[$i];
         if ($pred[1] >= 0) {
             print OUT  $pred[0] . "\t" . $pred[1] . "\t" . $pred[2] . "\t" . $annotation[$i-1] . "\n";
         }
    }
    close(OUT);
}


# The overall deltaG of the target binding duplex. This is similar to GC content
sub dG_binding {

    my $oligo = shift;
    $oligo =~ s/u/t/g;
    my $binding_dG = 0;
    for (my $indx = 0; $indx < length($oligo) - 1; $indx++) {
        next if substr($oligo, $indx, 2) =~ /n/;

         $binding_dG += $dG{substr($oligo, $indx, 2)};
    }
    $binding_dG += $dGi;

    return $binding_dG;
}

sub foldingdG {

   my $sequence = shift;

   my $tempSeq = "tempSeq$$";
   my $tempOUT = "tempOUT$$";

   $sequence =~ s/[5|3|'|\-|\s+]//g;
   $sequence =~ tr/Tt/Uu/;

   open(OLIGO, ">$tempSeq") or die "can not open $tempSeq for writing: $!\n";
   print OLIGO $sequence;
   close OLIGO;

   my $dG;
   system("./RNAfold < $tempSeq > $tempOUT");
   open(RESULT, "$tempOUT") or die "Cannot open $tempOUT for reading $!\n";
   while(my $line = <RESULT>){
      if($line =~ /([\-|\d][\.|\d]+)\)/){
         $dG = $1;
         last;
      }
   }
   close(RESULT);
   unlink $tempSeq;
   unlink $tempOUT;
   return $dG;
}

# Calculate the secondary structure delta G for a single input sequence
# Input - a single RNA oligo sequence
# Output - the deltaG value
sub RNA_fold {

   my $sequence = shift;

   my $tempSeq = "tempSeq$$";
   my $tempOUT = "tempOUT$$";

   $sequence =~ s/[5|3|'|\-|\s+]//g;
   $sequence =~ tr/Tt/Uu/;

   open(OLIGO, ">$tempSeq") or die "can not open $tempSeq for writing: $!\n";
   print OLIGO $sequence;
   close OLIGO;

   my ($dG, $align);
   system("./RNAfold < $tempSeq > $tempOUT");
   open(RESULT, "$tempOUT") or die "Cannot open $tempOUT for reading $!\n";
   while(my $line = <RESULT>){
         # ACCUUUUGUAUUUUAGUAACUGAAUCCCCACUGUGCAGUGUUAGGGCUGCCUGGUUGUUUGCAGUAGAUUAGAGCUUU
         # ..........(((((((.((((.((..(((..(.(((((......)))))))))..))...))))..))))))).... (-14.50)
         if($line =~ /([\-|\d][\.|\d]+)\)/){
             $dG = $1;
             if($line =~ /^([\.\(\)]+)\s+/){
                 $align = $1;
             }
             else {
                   print $line, "\tUm... RNAfold alignment is empty!\n"; exit;
             }
             last;
         }
   }
   close(RESULT);
   unlink $tempSeq;
   unlink $tempOUT;
   return ($dG, $align);
}

# The parameters are from the following paper:
# Sugimoto N, Nakano S, Katoh M, Matsumura A, Nakamuta H, Ohmichi T, Yoneyama M, Sasaki M.
# Thermodynamic parameters to predict stability of RNA/DNA hybrid duplexes.
# Biochemistry. 1995 Sep 5;34(35):11211-6.
sub rna_dna_param {

    my %dH = ();
    my %dS = ();
    my %dG = ();

    ($dH{'aa'}, $dS{'aa'}, $dG{'aa'}) = (-11.5, -36.4, -0.2);
    ($dH{'tt'}, $dS{'tt'}, $dG{'tt'}) = (-7.8, -21.9, -1.0);
    ($dH{'at'}, $dS{'at'}, $dG{'at'}) = (-8.3, -23.9, -0.9);
    ($dH{'ta'}, $dS{'ta'}, $dG{'ta'}) = (-7.8, -23.2, -0.6);
    ($dH{'ca'}, $dS{'ca'}, $dG{'ca'}) = (-10.4, -28.4, -1.6);
    ($dH{'tg'}, $dS{'tg'}, $dG{'tg'}) = (-9.0, -26.1, -0.9);
    ($dH{'ct'}, $dS{'ct'}, $dG{'ct'}) = (-9.1, -23.5, -1.8);
    ($dH{'ag'}, $dS{'ag'}, $dG{'ag'}) = (-7.0, -19.7, -0.9);
    ($dH{'ga'}, $dS{'ga'}, $dG{'ga'}) = (-8.6, -22.9, -1.5);
    ($dH{'tc'}, $dS{'tc'}, $dG{'tc'}) = (-5.5, -13.5, -1.3);
    ($dH{'gt'}, $dS{'gt'}, $dG{'gt'}) = (-5.9, -12.3, -2.1);
    ($dH{'ac'}, $dS{'ac'}, $dG{'ac'}) = (-7.8, -21.6, -1.1);
    ($dH{'cg'}, $dS{'cg'}, $dG{'cg'}) = (-16.3, -47.1, -1.7);
    ($dH{'gc'}, $dS{'gc'}, $dG{'gc'}) = (-8.0, -17.1, -2.7);
    ($dH{'gg'}, $dS{'gg'}, $dG{'gg'}) = (-9.3, -23.2, -2.1);
    ($dH{'cc'}, $dS{'cc'}, $dG{'cc'}) = (-12.8, -31.9, -2.9);

    my ($dHi, $dSi, $dGi) = (1.9, -3.9, 3.1);

    return (\%dH, \%dS, \%dG, $dHi, $dSi, $dGi);
}

# return the self-complementary strand of the input sequence
sub dnaComplement {
    my ($sequence) = @_;
    $sequence =~ tr/atcgATCG/tagcTAGC/;
    $sequence = reverse($sequence);
    return $sequence;
}

# calculate gc pecent range 0-1
sub gcPercent {
    my ($sequence) = @_;
    $sequence =~ tr/AUTCG/autcg/;
    my $length = length($sequence);
    my $gcCount= 0;

    for (my $j = 0; $j < $length; $j++) {
         if (substr($sequence, $j, 1) eq 'c' || substr($sequence, $j, 1) eq 'g') {
              $gcCount++;
         }
    }

    return sprintf("%.2f", $gcCount / $length);

}
