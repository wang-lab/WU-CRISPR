README - WU-CRISPR SERVER

WU-CRISPR is a tool for designing guide RNAs (gRNAs) for use in the CRISPR/Cas9 system for genome editing. You may use it freely in your research with appropriate acknowledgement. WU-CRISPR is provided �as is� and the author is not responsible for consequences from the use of this program. WU-CRISPR is distributed under the GNU General Public License as published by the Free Software foundation.

The WU-CRISPR server package can be downloaded from http://www.github.com/wang-lab/WU-CRISPR.

SYSTEM REQUIREMENTS
A Perl 5 interpreter or higher on a Linux system is required. Additional packages included with the WU-CRISPR Server are LIBSVM and RNAfold. RNAfold was compiled for RedHat Linux. Users may encounter issues running RNAfold and the WU-CRISPR Server on other Linux builds.

INSTALLATION

Place the WU-CRISPR_Server.tar.gz package in the cgi-bin of your Linux machine. The pathway defaults to /var/www/cgi-bin/

The WU-CRISPR server package can be unzipped using the following command:

	tar -xzvf WU-CRISPR_Server.tar.gz 

FILE AND DIRECTORY PERMISSIONS

The following files need to be set to 755 (Owner can read/write/execute, group and world can read/execute):

custom_gRNA.cgi
customDetail_gRNA.cgi
index.html
custom_guide/crispr.pl
custom_guide/RNAfold
All files in custom_guide/libsvm-2.82/

The following directories need to be set to 777 (Owner, group and world can read/write/execute):

custom_guide/
custom_guide/temp/

USAGE

To run the server program, access the custom_gRNA.cgi script from your web browser.



